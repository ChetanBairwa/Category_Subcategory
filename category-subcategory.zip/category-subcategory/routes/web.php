<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index',[CategoryController::class,'index']);

Route::any('category/create', [CategoryController::class, 'createCategory'])->name('category.createCategory');

Route::get('categories', [CategoryController::class, 'allCategories'])->name('allCategories');



// Route::get('editCategory', [CategoryController::class, 'editCategory'])->name('editCategory');
// Route::get('deleteCategory/{id}', [CategoryController::class, 'deleteCategory'])->name('category.deleteCategory');
Route::any('category/edit/{id}', [CategoryController::class, 'editCategory'])->name('category.editCategory');
Route::get('category/delete/{id}', [CategoryController::class, 'deleteCategory'])->name('deleteCategory');
