<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<section class="content" style="padding:50px 20%;">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border" >
                    {{-- <button class="btn"><a href="{{ route('category.createCategory') }}">Add New Category </a></button> --}}
                    <a href="{{route('category.createCategory')}}" class="add-new">
                        <button class="btn btn-primary btn-xs"> Add New Category </button>
                    </a>
                </div>
                @if(\Session::has('delete'))
                <li class="alert alert-danger">{!! \Session::get('delete') !!}</li>
                 @endif
                 
                 <div class="box-body">
                    <table class="table table-bordered table-striped" style="margin-top: 5px;">
                        <thead bgcolor="#ffaaaa;">
                            <tr style="text-align: center;">
                                <th>Id</th>
                                <th>Category Name</th>
                                <th>Category Slug</th>
                                <th>Parent Category</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            @foreach($categories as $category)
                            <tr>
                                <td>{{$category->id}}</td>
                                <td>{{$category->name}}</td>
                                <td>{{$category->slug}}</td>
                                <td>{{$category->parent_id}}</td>
                                {{-- <td>
                                     @if(isset($category->parent_id))
                                    {{$category->subcategory->name}}
                                @else
                                    None
                                @endif  --}}
                                </td>
                                <td>
                                    <a href="{{Route('category.editCategory', $category->id)}}">
                                        <button class="btn btn-sm btn-info">Edit</button>
                                    </a>
                                    <a href="{{Route('deleteCategory', $category->id)}}">
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </a>
                                </td>
                            </tr>
                           
                            @endforeach
                           
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        {!! $categories->links('vendor.pagination.custom') !!}
                    </div>
                </div>
            </div>
        </div>
   
</section>