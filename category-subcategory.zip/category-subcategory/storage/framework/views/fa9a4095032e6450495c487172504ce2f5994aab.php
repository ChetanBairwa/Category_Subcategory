<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<section class="content" style="padding:50px 20%;">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border" >
                    
                    <a href="<?php echo e(route('category.createCategory')); ?>" class="add-new">
                        <button class="btn btn-primary btn-xs"> Add New Category </button>
                    </a>
                </div>
                <?php if(\Session::has('delete')): ?>
                <li class="alert alert-danger"><?php echo \Session::get('delete'); ?></li>
                 <?php endif; ?>
                 
                 <div class="box-body">
                    <table class="table table-bordered table-striped" style="margin-top: 5px;">
                        <thead bgcolor="#ffaaaa;">
                            <tr style="text-align: center;">
                                <th>Id</th>
                                <th>Category Name</th>
                                <th>Category Slug</th>
                                <th>Parent Category</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->id); ?></td>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->slug); ?></td>
                                <td><?php echo e($category->parent_id); ?></td>
                                
                                </td>
                                <td>
                                    <a href="<?php echo e(Route('category.editCategory', $category->id)); ?>">
                                        <button class="btn btn-sm btn-info">Edit</button>
                                    </a>
                                    <a href="<?php echo e(Route('deleteCategory', $category->id)); ?>">
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </a>
                                </td>
                            </tr>
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <?php echo $categories->links('vendor.pagination.custom'); ?>

                    </div>
                </div>
            </div>
        </div>
   
</section><?php /**PATH C:\xampp\htdocs\category-subcategory\resources\views/all-category.blade.php ENDPATH**/ ?>